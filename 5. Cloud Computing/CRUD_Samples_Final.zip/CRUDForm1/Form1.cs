using System.Data;
using System.Data.SqlClient;

namespace CRUDForm1
{
    public partial class frmMain : Form
    {
        private const string ConnectionString = "Server=tcp:labuser79sqlserver.database.windows.net,1433;Initial Catalog=labuser79sql;Persist Security Info=False;User ID=winkey;Password=@Seoul20222022;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
        private SqlCo

        public frmMain()
        {
            InitializeComponent();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            
        }
}
}